<!-- jQuery -->
<script src="{{asset('panel/js/jquery.js')}}"></script>

<!-- Bootstrap Core JavaScript -->
<script src="{{asset('panel/js/bootstrap.min.js')}}"></script>

<script src="{{URL::to('parsley.min.js')}}"></script>


<script type="text/javascript">
   $('#exampleModal').modal('show')
</script>
