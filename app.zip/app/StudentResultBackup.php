<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StudentResultBackup extends Model
{
    protected $connection = 'mysql2';
}
