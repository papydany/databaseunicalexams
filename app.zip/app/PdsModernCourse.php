<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PdsModernCourse extends Model
{
    //
}
