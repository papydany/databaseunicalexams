<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        @inject('r','App\R')
         <?php $dept= $r->get_departmetname(Auth::user()->department_id) ?>
          <a class="navbar-brand" style="color:#fff;" href="{{url('/Deskofficer')}}"><strong>{{ $dept}}</strong></a>
       
    </div>
        
  @if (!Auth::guest())
 

    <ul class="nav navbar-right top-nav">
       
       

        <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i>  {{ Auth::user()->name }} <b class="caret"></b></a>
            <ul class="dropdown-menu">
        <li ><a href="{{ url('changepassword',Auth::user()->id) }}">Change Password</a></li>
                <li class="divider"></li>
                 <li>
                 <a href="{{ route('logout') }}" onclick="event.preventDefault();
                                            document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>
                <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                            {{ csrf_field() }}
                                        </form>
                                    </li>
             
            </ul>
        </li>
        
    </ul>
    @endif
    <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
    <div class="collapse navbar-collapse navbar-ex1-collapse">
        <ul class="nav navbar-nav side-nav">

        
            <li class="active">
                <a href="{{url('Deskofficer')}}"><i class="fa fa-fw fa-dashboard"></i> Dashboard</a>
            </li>
             <li>
                <a href="javascript:;" data-toggle="collapse" data-target="#demo1"><i class="fa fa-fw fa-bar-chart-o"></i> Lecturer<i class="fa fa-fw fa-caret-down"></i></a>
                <ul id="demo1" class="collapse">
                  <li>
                        <a href="{{url('new_lecturer')}}">New Lecturer</a>
                    </li>
                    <li>
                        <a href="{{url('view_lecturer')}}">View Lecturer</a>
                    </li>
                   
                </ul>
            </li>
                <li>
                <a href="javascript:;" data-toggle="collapse" data-target="#demo2"><i class="fa fa-fw fa-table"></i>Courses<i class="fa fa-fw fa-caret-down"></i></a>
                <ul id="demo2" class="collapse">
                    <li>
                        <a href="{{url('new_course')}}">New Courses</a>
                    </li>
                    <li>
                        <a href="{{url('view_course')}}">View Courses</a>
                    </li>
                   
                    <li>
                        <a href="{{url('register_course')}}">Register Courses</a>
                    </li>
                    <li>
                        <a href="{{url('view_register_course')}}">View Register Courses</a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="javascript:;" data-toggle="collapse" data-target="#demo3"><i class="fa fa-fw fa-edit"></i>Assign Courses<i class="fa fa-fw fa-caret-down"></i></a>
                <ul id="demo3" class="collapse">
                   <li>
                        <a href="{{url('assign_course')}}">Assign Courses</a>
                    </li>
                    <li>
                        <a href="{{url('view_assign_course')}}">View Assign Courses</a>
                    </li>
                </ul>
            </li>

             <li>
                <a href="javascript:;" data-toggle="collapse" data-target="#demo4"><i class="fa fa-fw fa-edit"></i>Student<i class="fa fa-fw fa-caret-down"></i></a>
                <ul id="demo4" class="collapse">
                    <li>
                        <a href="{{url('view_student')}}">Veiw Student </a>
                    </li>
                    <li>
                        <a href="{{url('register_student')}}">Register Student</a>
                    </li>

                   
                </ul>
            </li>
             

  <li>
                <a href="javascript:;" data-toggle="collapse" data-target="#demo5"><i class="fa fa-fw fa-edit"></i>Result<i class="fa fa-fw fa-caret-down"></i></a>
                <ul id="demo5" class="collapse">
                    <li>
                        <a href="{{url('e_result')}}">Enter result</a>
                    </li>
                    <li>
                        <a href="{{url('view_result')}}">View result</a>
                    </li>
                </ul>
            </li>
            
         
          
        </ul>
    </div>
    <!-- /.navbar-collapse -->
</nav>